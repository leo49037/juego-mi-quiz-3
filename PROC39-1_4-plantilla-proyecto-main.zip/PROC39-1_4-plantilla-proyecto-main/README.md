# PROC39-1_4-plantilla-proyecto
## Plantilla del proyecto para la clase 39 nivel PRO 1:4.
Modificación por parte del alumno de dos comentarios y cambio en la configuración de Firebase de la base de datos. Etapa 3.

### Nombre en Inglés: project-template-my-quiz3